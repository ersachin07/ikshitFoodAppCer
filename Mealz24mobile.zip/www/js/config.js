var krms_config ={		
	'ApiUrl':"http://hedgebulls.in/mealz24/mobileapp/api",				
	'DialogDefaultTitle':"Mealz24",	
	'APIHasKey':"qazwsx123edc4rfv56789",
	'debug': false
};


